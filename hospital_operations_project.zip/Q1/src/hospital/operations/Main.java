package hospital.operations;

import java.util.Scanner;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) {
        Operations ops = new Operations();
        int[][] data = ops.getData();
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("HOSPITAL OPERATIONS APPLICATION");
        System.out.println("-------------------------------");
        System.out.println("Please enter the operation results to display:");
        System.out.println("1) Total Operations:");
        System.out.println("2) Average Operations:");
        System.out.println("3) Max Operations:");
        System.out.println("4) Min Operations:");
        System.out.print("Enter choice (1-4): ");

        String choice = sc.nextLine().trim();
        System.out.println();
        switch (choice) {
            case "1":
                System.out.println("HOSPITAL OPERATIONS APPLICATION");
                System.out.println("-------------------------------");
                System.out.println("Total Operations: " + ops.TotalOperations(data));
                break;
            case "2":
                System.out.println("HOSPITAL OPERATIONS APPLICATION");
                System.out.println("-------------------------------");
                System.out.println("Average Operations: " + df.format(ops.AverageOperations(data)));
                break;
            case "3":
                System.out.println("HOSPITAL OPERATIONS APPLICATION");
                System.out.println("-------------------------------");
                System.out.println("Max Operations: " + ops.MaxOperations(data));
                break;
            case "4":
                System.out.println("HOSPITAL OPERATIONS APPLICATION");
                System.out.println("-------------------------------");
                System.out.println("Min Operations: " + ops.MinOperations(data));
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
        }
        sc.close();
    }
}
