package hospital.operations;

public class Operations implements IOperations {
    // Data supplied in the assignment
    private final int[][] data = {
        {320, 175, 380}, // Year 1 quarters 1..3
        {210, 125, 360}  // Year 2
    };

    public int[][] getData() {
        return data;
    }

    @Override
    public int TotalOperations(int[][] operations) {
        int total = 0;
        for (int[] row : operations) {
            for (int v : row) total += v;
        }
        return total;
    }

    @Override
    public double AverageOperations(int[][] operations) {
        int total = TotalOperations(operations);
        int count = 0;
        for (int[] row : operations) count += row.length;
        return (double) total / count;
    }

    @Override
    public int MaxOperations(int[][] operations) {
        int max = Integer.MIN_VALUE;
        for (int[] row : operations) {
            for (int v : row) if (v > max) max = v;
        }
        return max;
    }

    @Override
    public int MinOperations(int[][] operations) {
        int min = Integer.MAX_VALUE;
        for (int[] row : operations) {
            for (int v : row) if (v < min) min = v;
        }
        return min;
    }
}
