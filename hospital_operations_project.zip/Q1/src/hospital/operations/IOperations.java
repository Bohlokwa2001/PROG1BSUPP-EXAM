package hospital.operations;

public interface IOperations {
    int TotalOperations(int[][] operations);
    double AverageOperations(int[][] operations);
    int MaxOperations(int[][] operations);
    int MinOperations(int[][] operations);
}
