package hospital.operations;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OperationsTest {
    @Test
    public void TotalOperations_ReturnsValue() {
        Operations ops = new Operations();
        int[][] data = ops.getData();
        int total = ops.TotalOperations(data);
        // expected: 320+175+380 + 210+125+360 = 1570
        assertEquals(1570, total);
    }

    @Test
    public void AverageOperations_ReturnsValue() {
        Operations ops = new Operations();
        int[][] data = ops.getData();
        double avg = ops.AverageOperations(data);
        // expected 1570 / 6 = 261.666...
        assertEquals(1570.0/6.0, avg, 0.0001);
    }
}
