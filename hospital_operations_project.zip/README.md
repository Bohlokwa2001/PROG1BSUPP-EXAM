Hospital Operations Project
===========================

This ZIP contains solutions for:
- Question 1: Console Java application (interface, Operations class, menu-driven Main) + unit tests (JUnit 5)
- Question 2: Java Swing GUI application (interface, Operations class, GUI Main) + unit tests (JUnit 5)

Project layout:
- Q1/src/hospital/operations/IOperations.java
- Q1/src/hospital/operations/Operations.java
- Q1/src/hospital/operations/Main.java
- Q1/tests/hospital/operations/OperationsTest.java

- Q2/src/hospital/gui/IOperationsGUI.java
- Q2/src/hospital/gui/OperationsGUI.java
- Q2/src/hospital/gui/MainGUI.java
- Q2/tests/hospital/gui/OperationsGUITest.java

Notes:
- Unit tests use JUnit 5 (org.junit.jupiter). To run tests, ensure JUnit 5 is on the classpath.
- The GUI uses Java Swing. To run:
    javac -d out $(find Q2/src -name "*.java")
    java -cp out hospital.gui.MainGUI
- Console app:
    javac -d out $(find Q1/src -name "*.java")
    java -cp out hospital.operations.Main
- Saving from the GUI writes a file named 'data.txt' in the working directory.
