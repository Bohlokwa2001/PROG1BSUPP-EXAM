package hospital.gui;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OperationsGUITest {
    @Test
    public void OperationsYearOne_ReturnsTotalOperations() {
        OperationsGUI ops = new OperationsGUI();
        int total1 = ops.GetTotalOperationsForYearOne();
        // expected: 300+150+700 = 1150
        assertEquals(1150, total1);
    }

    @Test
    public void OperationsYearTwo_ReturnsTotalOperations() {
        OperationsGUI ops = new OperationsGUI();
        int total2 = ops.GetTotalOperationsForYearTwo();
        // expected: 250+200+600 = 1050
        assertEquals(1050, total2);
    }
}
