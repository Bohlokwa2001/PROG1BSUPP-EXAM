package hospital.gui;

public interface IOperationsGUI {
    int[][] GetOperationsData();
    int GetTotalOperations();
    int GetTotalOperationsForYearOne();
    int GetTotalOperationsForYearTwo();
}
