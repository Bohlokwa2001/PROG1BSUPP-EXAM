package hospital.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class MainGUI {
    private final OperationsGUI ops = new OperationsGUI();
    private JFrame frame;
    private JTextArea textArea;
    private JComboBox<String> combo;

    public MainGUI() {
        initUI();
    }

    private void initUI() {
        frame = new JFrame("Hospital Operations GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem saveItem = new JMenuItem("Save Data");
        JMenuItem clearItem = new JMenuItem("Clear");
        toolsMenu.add(processItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        frame.setJMenuBar(menuBar);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10,10));

        JPanel top = new JPanel();
        JButton processBtn = new JButton("Process");
        JButton saveBtn = new JButton("Save Data");
        combo = new JComboBox<>(new String[]{"Total operations","Total operations for Year 1","Total operations for Year 2"});
        top.add(processBtn);
        top.add(saveBtn);
        top.add(combo);

        textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(textArea);

        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        frame.add(panel);

        // Actions
        ActionListener doProcess = e -> processData();
        ActionListener doSave = e -> saveData();
        ActionListener doClear = e -> textArea.setText("");

        processBtn.addActionListener(doProcess);
        saveBtn.addActionListener(doSave);

        processItem.addActionListener(doProcess);
        saveItem.addActionListener(doSave);
        clearItem.addActionListener(doClear);

        frame.setVisible(true);
    }

    private void processData() {
        String sel = (String) combo.getSelectedItem();
        StringBuilder sb = new StringBuilder();
        if (sel.equals("Total operations")) {
            int total = ops.GetTotalOperations();
            sb.append("Total operations: ").append(total).append("\n");
        } else if (sel.equals("Total operations for Year 1")) {
            int total1 = ops.GetTotalOperationsForYearOne();
            sb.append("Total operations for year 1: ").append(total1).append("\n");
        } else {
            int total2 = ops.GetTotalOperationsForYearTwo();
            sb.append("Total operations for year 2: ").append(total2).append("\n");
        }
        textArea.setText(sb.toString());
    }

    private void saveData() {
        String content = textArea.getText();
        if (content == null || content.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Nothing to save. Process data first.");
            return;
        }
        try (FileWriter fw = new FileWriter("data.txt", false)) {
            fw.write(content);
            JOptionPane.showMessageDialog(frame, "Saved to data.txt");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Failed to save: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainGUI::new);
    }
}
