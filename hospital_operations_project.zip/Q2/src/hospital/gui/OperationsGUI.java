package hospital.gui;

public class OperationsGUI implements IOperationsGUI {
    // Planned, Unplanned, Emergency
    private final int[][] data = {
        {300, 150, 700}, // Year 1
        {250, 200, 600}  // Year 2
    };

    @Override
    public int[][] GetOperationsData() {
        return data;
    }

    @Override
    public int GetTotalOperations() {
        int total = 0;
        for (int[] row : data) for (int v : row) total += v;
        return total;
    }

    @Override
    public int GetTotalOperationsForYearOne() {
        int total = 0;
        for (int v : data[0]) total += v;
        return total;
    }

    @Override
    public int GetTotalOperationsForYearTwo() {
        int total = 0;
        for (int v : data[1]) total += v;
        return total;
    }
}
